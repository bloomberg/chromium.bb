chrome.experimental.runtime.onLaunched.addListener(function() {
  chrome.windows.create({
      url: 'calculator.html',
      type: 'shell',
      width: 217,
      height: 223
  });
});

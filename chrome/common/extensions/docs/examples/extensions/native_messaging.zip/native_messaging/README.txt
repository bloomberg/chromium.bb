Before using this extension, you must register the native client (echo.py).

To register the client, you will first need to create a directory called
"Native Hosts" beside your user data directory
(http://www.chromium.org/user-experience/user-data-directory). Then, move
echo.py into this new directory.

The client is written in Python and will need the python executable to run.
